from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import admin
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from .models  import sample,Book1,Book2,Book3,Book4,Book5,project
# Create your views here.
def index(request):
    return render(request,'login1.html')
def finallogin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request,username=username, password=password)
        if request.user.is_superuser:
            return redirect('branches1')
        elif user is not None:
            login(request, user)
            return redirect('branches')
        else:
            messages.success(request,'there was an error logging in try again')
            return redirect('finallogin')
    else:       
        return render(request,'finallogin.html')
def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password == password2:
            if User.objects.filter(email=email).exists():
                messages.info(request,'email Already exist')
                return redirect('signup')
            elif User.objects.filter(username=username).exists():
                messages.info(request,'username Already exist')
                return redirect('signup')    
            else:
                user=User.objects.create_user(username=username,email=email,password=password) 
                user.save();
                return redirect('finallogin')
        else:   
            messages.info(request,'password not the same')         
            return redirect('signup')
    else:
        return render(request,'signup.html')
def password1(request):
    if request.method == 'POST':
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        
        if password1 == password2:
                user=User.objects.get(username=username) 
                user.set_password(password1)
                user.save();
                return redirect('finallogin')
        else:   
            messages.info(request,'password not the same')         
            return redirect('password')
    else:
       return render(request,'password.html')
def reset(request):
    if request.method == 'POST':
        username = request.POST['username']
        if not  User.objects.filter(username=username).exists():
            messages.success(request,'there was an error logging in try again')
            return redirect('reset')
           
        else:
            return redirect('password')
    else:       
        return render(request,'reset.html')
def branches(request):
    return render(request,'branches.html')
def cselabs(request):
    return render(request,'cselabs.html')
def ecelabs(request):
    return render(request,'ecelabs.html')
def eeelabs(request):
    return render(request,'eeelabs.html')
def itlabs(request):
    return render(request,'itlabs.html')
def csmlabs(request):
    return render(request,'csmlabs.html')
#def base(request):
    obj=sample.objects.all()
    return render(request ,"base.html",{'obj': obj})
def logout1(request):
    return render(request ,'logout1.html')
def images1(request):
    return render(request ,'images1.html')
def lab1(request):
     obj=Book1.objects.all()
     return render(request ,"lab1.html",{'obj': obj})
def lab2(request):
    obj=Book2.objects.all()
    return render(request ,"lab2.html",{'obj': obj})
def lab3(request):
    obj=Book3.objects.all()
    return render(request ,"lab3.html",{'obj': obj})
def lab4(request):
    obj=Book4.objects.all()
    return render(request ,"lab4.html",{'obj': obj})
def lab5(request):
    obj=Book5.objects.all()
    return render(request ,"lab5.html",{'obj': obj})
def proj(request):
    obj=project.objects.all()
    return render(request,"project.html",{'obj':obj})
def branches1(request):
    return render(request,'admins/branches1.html')
def alab1(request):
    obj=Book1.objects.all()
    return render(request ,"admins/alab1.html",{'obj': obj})
def alab2(request):
    obj=Book2.objects.all()
    return render(request ,"admins/alab2.html",{'obj': obj})
def alab3(request):
    obj=Book3.objects.all()
    return render(request ,"admins/alab3.html",{'obj': obj})
def alab4(request):
    obj=Book4.objects.all()
    return render(request ,"admins/alab4.html",{'obj': obj})
def alab5(request):
    obj=Book5.objects.all()
    return render(request ,"admins/alab5.html",{'obj': obj})
def aproject(request):
    obj=project.objects.all()
    return render(request ,"admins/aproject.html",{'obj': obj})





