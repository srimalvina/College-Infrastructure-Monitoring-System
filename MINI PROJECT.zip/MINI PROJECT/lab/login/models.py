from django.db import models


# Create your models here.
class  sample(models.Model):
   Sno=models.CharField(max_length=200)
   Room_Description=models.CharField(max_length=200)
   Description=models.CharField(max_length=200)
   In_charge=models.CharField(max_length=200)
   Technical_Programmers=models.CharField(max_length=200)
   Rooms_equipped_with=models.CharField(max_length=200)
   
class  Book1(models.Model):
   Lab_Description=models.CharField(max_length=200)
   Room_No=models.CharField(max_length=200)
   No_Of_Systems=models.CharField(max_length=200)
   Description=models.CharField(max_length=200)
   No_Of_Routers=models.CharField(max_length=200)
   No_Of_Switches=models.CharField(max_length=200)
   In_charge=models.CharField(max_length=200)
   Technical_Programmers=models.CharField(max_length=200)
   Rooms_equipped_with=models.CharField(max_length=200)
 
class  Book2(models.Model):
   Lab_Description=models.CharField(max_length=200)
   Room_No=models.CharField(max_length=200)
   No_Of_Systems=models.CharField(max_length=200)
   Description=models.CharField(max_length=200)
   No_Of_Routers=models.CharField(max_length=200)
   No_Of_Switches=models.CharField(max_length=200)
   In_charge=models.CharField(max_length=200)
   Technical_Programmers=models.CharField(max_length=200)
   Rooms_equipped_with=models.CharField(max_length=200)
 
class  Book3(models.Model):
   Lab_Description=models.CharField(max_length=200)
   Room_No=models.CharField(max_length=200)
   No_Of_Systems=models.CharField(max_length=200)
   Description=models.CharField(max_length=200)
   No_Of_Routers=models.CharField(max_length=200)
   No_Of_Switches=models.CharField(max_length=200)
   In_charge=models.CharField(max_length=200)
   Technical_Programmers=models.CharField(max_length=200)
   Rooms_equipped_with=models.CharField(max_length=200)

class  Book4(models.Model):
   Lab_Description=models.CharField(max_length=200)
   Room_No=models.CharField(max_length=200)
   No_Of_Systems=models.CharField(max_length=200)
   Description=models.CharField(max_length=200)
   No_Of_Routers=models.CharField(max_length=200)
   No_Of_Switches=models.CharField(max_length=200)
   In_charge=models.CharField(max_length=200)
   Technical_Programmers=models.CharField(max_length=200)
   Rooms_equipped_with=models.CharField(max_length=200)

class  Book5(models.Model):
   Lab_Description=models.CharField(max_length=200)
   Room_No=models.CharField(max_length=200)
   No_Of_Systems=models.CharField(max_length=200)
   Description=models.CharField(max_length=200)
   No_Of_Routers=models.CharField(max_length=200)
   No_Of_Switches=models.CharField(max_length=200)
   In_charge=models.CharField(max_length=200)
   Technical_Programmers=models.CharField(max_length=200)
   Rooms_equipped_with=models.CharField(max_length=200)

class  project(models.Model):
   Lab_Description=models.CharField(max_length=200)
   Room_No=models.CharField(max_length=200)
   No_Of_Systems=models.CharField(max_length=200)
   Description=models.CharField(max_length=200)
   No_Of_Routers=models.CharField(max_length=200)
   No_Of_Switches=models.CharField(max_length=200)
   In_charge=models.CharField(max_length=200)
   Technical_Programmers=models.CharField(max_length=200)
   Rooms_equipped_with=models.CharField(max_length=200)
 
 
 
 

   def _str_(self):
         return self.Sno
           					
