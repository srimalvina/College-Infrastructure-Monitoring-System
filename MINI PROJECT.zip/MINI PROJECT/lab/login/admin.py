from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models  import sample
from .models  import Book1,Book2,Book3,Book4,Book5,project

# Register your models here.

admin.site.register(sample,ImportExportModelAdmin),
admin.site.register(Book1,ImportExportModelAdmin),
admin.site.register(Book2,ImportExportModelAdmin),
admin.site.register(Book3,ImportExportModelAdmin),
admin.site.register(Book4,ImportExportModelAdmin),
admin.site.register(Book5,ImportExportModelAdmin),
admin.site.register(project,ImportExportModelAdmin),
