from django.urls import path
from . import views

urlpatterns =[
    path('',views.index,name='login1'),
    path('finallogin/',views.finallogin,name='finallogin'),
    path('signup/',views.signup,name='signup'),
    path('branches/',views.branches,name='branches'),
   # path('base/',views.base,name='base'),
    path('logout1/',views.logout1,name='logout1'),
    path('images1/',views.images1,name='images1'),
    path('lab1/',views.lab1,name='lab1'),
    path('lab2/',views.lab2,name='lab2'),
    path('lab3/',views.lab3,name='lab3'),
    path('lab4/',views.lab4,name='lab4'),
    path('lab5/',views.lab5,name='lab5'),
    path('project/',views.proj,name='project'),
    path('password/',views.password1,name='password'),
    path('reset/',views.reset,name='reset'),
    path('branches1/',views.branches1,name='branches1'),
    path('alab1/',views.alab1,name='alab1'),
    path('alab2/',views.alab2,name='alab2'),
    path('alab3/',views.alab3,name='alab3'),
    path('alab4/',views.alab4,name='alab4'),
    path('alab5/',views.alab5,name='alab5'),
    path('aproject/',views.aproject,name='aproject'),


]

